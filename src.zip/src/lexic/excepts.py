class LexicalException(Exception):
	"""
    	Represents a lexical error.
    	Inherits from the base Exception class.
	"""
	pass